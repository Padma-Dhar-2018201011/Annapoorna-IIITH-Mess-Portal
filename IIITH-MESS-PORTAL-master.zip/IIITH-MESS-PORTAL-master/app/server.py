from flask import Flask

import model

app = Flask(__name__)

