# IIITH-MESS-PORTAL

To run the code install flask and other python libraries mentioned in the code and run using the command python run.py.
